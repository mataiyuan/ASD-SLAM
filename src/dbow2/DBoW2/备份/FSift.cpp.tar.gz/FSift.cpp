/**
 * File: FSift.cpp
 * Date: April 2015
 * Author: Thierry Malon
 * Description: functions for Sift descriptors
 * License: see the LICENSE.txt file
 *
 */

#include <vector>
#include <string>
#include <sstream>
#include <iostream>
#include "FClass.h"
#include "FSift.h"

using namespace std;

namespace DBoW2 {

// --------------------------------------------------------------------------

void FSift::meanValue(const std::vector<FSift::pDescriptor> &descriptors,
  FSift::TDescriptor &mean)
{


  //vector<float> mean_tmp = vector<float>( (mean.reshape(1, 1)));
  vector<float> mean_tmp;
  mean_tmp.resize(0);
  mean_tmp.resize(FSift::L, 0);

  float s = descriptors.size();

  vector<FSift::pDescriptor>::const_iterator it;
  for(it = descriptors.begin(); it != descriptors.end(); ++it)
  {
     FSift::pDescriptor it_tmp = *it;
     //cout<<"first"<<*it_tmp<<endl;
    vector<float> desc_tmp = vector<float>( (it_tmp->reshape(1, 1)));
 /* cout<<"second"<<endl;
  cout<<*it_tmp<<endl;
  cout<<"line1"<<endl;
  cout<<it_tmp->reshape(1, 1)<<endl;
  cout<<"line2"<<endl;
  cout<<"desc_tmp.size"<<endl;
  for(int i = 0 ; i<desc_tmp.size() ; i++ )
  {
      cout<<desc_tmp.at(i)<<",";
  }
 cout<<endl;
*/


   // const FSift::TDescriptor &desc = **it;
    for(int i = 0; i < FSift::L; i += 4)
    {
      mean_tmp[i  ] += desc_tmp[i  ] / s;
      mean_tmp[i+1] += desc_tmp[i+1] / s;
      mean_tmp[i+2] += desc_tmp[i+2] / s;
      mean_tmp[i+3] += desc_tmp[i+3] / s;
    }
  }

  cv::Mat mat = cv::Mat(mean_tmp);//将vector变成单列的mat
  mean = mat.reshape(1,1).clone();//PS：必须clone()一份，否则返回出错
}

// --------------------------------------------------------------------------

double FSift::distance(const FSift::TDescriptor &a, const FSift::TDescriptor &b)
{

  vector<float> a_tmp = vector<float>( (a.reshape(1, 1)));
   vector<float> b_tmp = vector<float>( (b.reshape(1, 1)));
  double sqd = 0.;
  for(int i = 0; i < FSift::L; i += 4)
  {
    sqd += (a_tmp[i  ] - b_tmp[i  ])*(a_tmp[i  ] - b_tmp[i  ]);
    sqd += (a_tmp[i+1] - b_tmp[i+1])*(a_tmp[i+1] - b_tmp[i+1]);
    sqd += (a_tmp[i+2] - b_tmp[i+2])*(a_tmp[i+2] - b_tmp[i+2]);
    sqd += (a_tmp[i+3] - b_tmp[i+3])*(a_tmp[i+3] - b_tmp[i+3]);
  }
  return sqd;
}

// --------------------------------------------------------------------------



// --------------------------------------------------------------------------


void FSift::toMat32F(const std::vector<TDescriptor> &descriptors,
    cv::Mat &mat)
{
  if(descriptors.empty())
  {
    mat.release();
    return;
  }

  const int N = descriptors.size();
  const int L = FSift::L;

  mat.create(N, L, CV_32F);

  for(int i = 0; i < N; ++i)
  {
    const TDescriptor& desc = descriptors[i];
    float *p = mat.ptr<float>(i);
    for(int j = 0; j < L; ++j, ++p)
    {
      *p = desc[j];
    }
  }
}


// --------------------------------------------------------------------------

} // namespace DBoW2


