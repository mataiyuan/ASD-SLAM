#include <pcl/recognition/ransac_based/obj_rec_ransac.h>
#error "Using pcl/recognition/obj_rec_ransac.h is deprecated, please use pcl/recognition/ransac_based/obj_rec_ransac.h instead."