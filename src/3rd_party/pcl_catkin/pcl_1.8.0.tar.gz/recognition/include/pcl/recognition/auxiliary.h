#include <pcl/recognition/ransac_based/auxiliary.h>
#error "Using pcl/recognition/auxiliary.h is deprecated, please use pcl/recognition/ransac_based/auxiliary.h instead."